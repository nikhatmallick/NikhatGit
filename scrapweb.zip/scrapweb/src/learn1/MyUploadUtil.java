package learn1;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.disk.*;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.util.*;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItem;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.fileupload.servlet.ServletRequestContext;

/**
 * Servlet implementation class MyUploadUtil
 */

public class MyUploadUtil extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final int KB = 1024;
	private static final int MB = 1024 * 1024;
	private static final int MEMORY_THRESHOLD = KB * 2;
	private static final int FILE_SIZE_MAX = MB * 30;
	private static final int REQUEST_SIZE_MAX = MB * 50;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MyUploadUtil() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter writer = response.getWriter();
		writer.append(getServletName()).println("ha");
		writer.println(" will it work?");
		writer.flush();
		if (request.getContentType() == null) {
			return;
		}

		if (!request.getContentType().startsWith("multipart/form-data")) {
			writer.println(
					"not a multi-part/form-data post; standard servlet methods should be used to retrieve parameters");
			return;
		}

		if (!ServletFileUpload.isMultipartContent(request)) {
			writer.println("second check of not multipart");
			writer.flush();
			return;
		}

		DiskFileItemFactory diskFactory = new DiskFileItemFactory();
		// max size that will be stored in memory before spooling to disk
		diskFactory.setSizeThreshold(MEMORY_THRESHOLD);
		// temp location to get all parts of file
		String tempDir = System.getProperty("java.io.tempdir");
		File tempFile = new File(tempDir);
		diskFactory.setRepository(tempFile);
		writer.println("path to temp spooling: " + diskFactory.getRepository().getAbsolutePath());
		writer.flush();
		// file upload handler
		ServletFileUpload fileUpload = new ServletFileUpload(diskFactory);
		fileUpload.setFileSizeMax(FILE_SIZE_MAX);
		fileUpload.setSizeMax(REQUEST_SIZE_MAX);
		String fileUploadPath = "C:\\Users\\Owner\\OneDrive\\Documents\\Dev\\mywars\\s3bucket";
		try {
			List formItems = fileUpload.parseRequest(request);
			if (formItems.size() > 0 && formItems != null) {
				Iterator item = formItems.iterator();
				while (item.hasNext()) {

					FileItem fi = (FileItem) item.next();
					if (!fi.isFormField()) {
						String fileName = fi.getName();
						String contentType = fi.getContentType();
						boolean isInMemory = fi.isInMemory();
						long sizeInBytes = fi.getSize();
						writer.println(String.format("[filename]:[%s] " + "[contentType]:[%s] " + "[isInMemory]:[%b] "+ "[sizeInBytes]:[%d]",
								fileName, contentType, isInMemory, sizeInBytes));
						writer.flush();
						String fileWPath = "C:\\Users\\Owner\\OneDrive\\Documents\\Dev\\mywars\\s3bucket\\" + fileName;
						
						fi.write(new File(fileWPath));
						writer.println("uploaded");
						writer.flush();
						request.setAttribute("message", "uploaded successfully in s3 bucket");
					}
				}
			}
		} catch (Exception ex) {
			writer.println("some exception: " + ex.getMessage());
			request.setAttribute("message", "failed to upload: " + ex.getMessage());
		}
		getServletContext().getRequestDispatcher("/message.jsp").forward(request, response);
	}

}
