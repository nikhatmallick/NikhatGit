package com.uciext.springfw.hw.catalog.service.impl;

import org.apache.log4j.Logger;
import com.uciext.springfw.hw.catalog.model.Catalog;
import com.uciext.springfw.hw.catalog.service.CatalogService;

public class CatalogServiceImpl implements CatalogService{
	private Catalog catalog1;
	private static Logger log =  Logger.getLogger(CatalogServiceImpl.class);

	protected CatalogServiceImpl( ) {
		
	log.info("In CatalogServiceImpl()");	
	}

	@Override
	public Catalog getCatalog( ) {
		// TODO Auto-generated method stub
			return catalog1;
	}

	public Catalog getCatalog1() {
		return catalog1;
	}

	public void setCatalog1(Catalog value) {
		this.catalog1 = value;
	}
	
	

}
