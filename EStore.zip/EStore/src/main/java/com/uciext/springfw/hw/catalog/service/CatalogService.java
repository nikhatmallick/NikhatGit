package com.uciext.springfw.hw.catalog.service;

import com.uciext.springfw.hw.catalog.model.Catalog;

public interface CatalogService {
	public Catalog getCatalog( );

}
