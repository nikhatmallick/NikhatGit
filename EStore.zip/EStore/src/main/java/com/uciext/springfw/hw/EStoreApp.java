package com.uciext.springfw.hw;

import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import com.uciext.springfw.hw.catalog.model.Catalog;
import com.uciext.springfw.hw.catalog.service.CatalogService;

public class EStoreApp {
	private static Logger logger = Logger.getLogger(EStoreApp.class);
//	static Logger logger = LogManager.getLogger(EStoreApp.class);
	
	private void getLoggerLevel(String message) {
		if(logger.isDebugEnabled())
			logger.debug("This is set to debug level " + message);
		if(logger.isInfoEnabled())
			logger.info("This is set to Info level " + message);
	}

	public static void main(String[] args)  throws Exception {
		// TODO Auto-generated method stub
		logger.info("EStoreApp - Start");
		//logger.debug("this should'nt print as we are not set to debug level");
		EStoreApp estoreApp = new EStoreApp();
		//estoreApp.getLoggerLevel("mode");
		
		BeanFactory factory = new XmlBeanFactory(new  ClassPathResource("/META-INF/spring/EStoreContext.xml"));
		CatalogService catalogService = (CatalogService) factory.getBean("catalogService");
		logger.info("EStoreApp - Catalog:");
		Catalog catalog1 = catalogService.getCatalog();
		System.out.println(catalog1.toString());

	}

}
