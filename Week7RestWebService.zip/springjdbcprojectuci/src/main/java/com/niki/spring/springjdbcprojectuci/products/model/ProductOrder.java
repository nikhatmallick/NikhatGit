package com.niki.spring.springjdbcprojectuci.products.model;

public class ProductOrder {

}
