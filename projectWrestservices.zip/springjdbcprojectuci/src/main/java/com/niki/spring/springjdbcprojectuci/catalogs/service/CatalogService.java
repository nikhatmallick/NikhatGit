package com.niki.spring.springjdbcprojectuci.catalogs.service;

import java.util.List;

import com.niki.spring.springjdbcprojectuci.catalogs.model.Catalog;
import com.niki.spring.springjdbcprojectuci.products.model.Product;

public interface CatalogService {
	//catalog
	public void insertCatalog(Catalog catalog) ;
	public List<Catalog> getCatalogs();
	public Catalog getCatalog(int catalog_id);
	//public void deleteCatalog(int catalog_id);
	//product
	public void insertProduct(Product product);
	public List<Product> getProducts();
	public Product getProduct(int product_id);
	public List<Product> getProductsByCatalog(Catalog catalog);
}
