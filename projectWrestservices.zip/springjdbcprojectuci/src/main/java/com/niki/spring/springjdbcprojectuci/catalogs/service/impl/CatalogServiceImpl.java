package com.niki.spring.springjdbcprojectuci.catalogs.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.niki.spring.springjdbcprojectuci.catalogs.dao.CatalogDao;
import com.niki.spring.springjdbcprojectuci.catalogs.dao.ProductDao;
import com.niki.spring.springjdbcprojectuci.catalogs.model.Catalog;
import com.niki.spring.springjdbcprojectuci.catalogs.service.CatalogService;
import com.niki.spring.springjdbcprojectuci.products.model.Product;

public class CatalogServiceImpl implements CatalogService {

	static final Logger logger = Logger.getLogger(CatalogServiceImpl.class.getName());
	CatalogDao catalogDao;
	ProductDao productDao;

	
	public void setProductDao(ProductDao productDao) {
		this.productDao = productDao;
	}

	public void setCatalogDao(CatalogDao catalogDao) {
		this.catalogDao = catalogDao;
	}
	
	// Catalogs
	@Override
	public void insertCatalog(Catalog catalog) {
		System.out.println("insert this catalog: " + catalog);
		catalogDao.insertCatalog(catalog);

	}

	@Override
	public List<Catalog> getCatalogs() {
		System.out.println("all teh catalogs:");
		return catalogDao.findCatalogs();
	}

	@Override
	public Catalog getCatalog(int catalog_id) {
		return catalogDao.findCatalogById(catalog_id);
	}
	

	
//product
	@Override
	public void insertProduct(Product product) {
		productDao.insertProduct(product);
	}

	@Override
	public List<Product> getProducts() {
		return productDao.findProducts();
	}

	@Override
	public Product getProduct(int product_id) {
		return productDao.findProductById(product_id);
	}


	@Override
	public List<Product> getProductsByCatalog(Catalog catalog) {
		System.out.println("--- getProductsByCatalog() catalog=" + catalog);
		return productDao.findProductsByCatalog(catalog);
	}

	

}
